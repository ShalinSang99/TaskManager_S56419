package com.example.taskManager

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Version : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_version)

        val actionBar = supportActionBar

        actionBar!!.title = "Version"

        actionBar.setDisplayHomeAsUpEnabled(true)
    }
}