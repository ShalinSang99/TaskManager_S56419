package com.example.taskManager

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {
    lateinit var toggle: ActionBarDrawerToggle
    private lateinit var adapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        adapter = Adapter(mutableListOf())


        rvTodoItems.adapter = adapter
        rvTodoItems.layoutManager = LinearLayoutManager(this)

        btnAddItem.setOnClickListener {
            val todoTitle = etItemTitle.text.toString()
            if (todoTitle.isNotEmpty()) {
                val todo = Task(todoTitle)
                adapter.addTodo(todo)
                etItemTitle.text.clear()
            }
        }
        btnDeleteItem.setOnClickListener {
            adapter.deleteDoneTodos()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.nav_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId;
        if (id == R.id.nav_home){
            val intent = Intent(this, About::class.java)
            startActivity(intent)
        };
        if (id == R.id.nav_contact){
            val intent = Intent(this, Contact::class.java)
            startActivity(intent)
        };
        if(id == R.id.nav_version){
            val intent = Intent(this, Version::class.java)
            startActivity(intent)
        }else{
            return false
        }
        return super.onOptionsItemSelected(item)
    }
}