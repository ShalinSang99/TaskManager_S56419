package com.example.taskManager

data class Task(
    val title: String,
    var isChecked: Boolean = false
)